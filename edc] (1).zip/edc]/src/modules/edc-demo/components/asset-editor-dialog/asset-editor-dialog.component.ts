import { Component, Inject, OnInit } from '@angular/core';
import { AssetEntryDto, AssetService } from "../../../mgmt-api-client";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { StorageType } from "../../models/storage-type";


@Component({
  selector: 'edc-demo-asset-editor-dialog',
  templateUrl: './asset-editor-dialog.component.html',
  styleUrls: ['./asset-editor-dialog.component.scss']
})
export class AssetEditorDialog implements OnInit {

  id: string = '';
  version: string = '';
  name: string = '';
  contenttype: string = '';

  storageTypeId: string = 'HttpData';
  account: string = '';
  container: string = 'src-container';
  blobname: string = '';
  sourceData: any =
    [{ name: "Batch Data", path: "http://localhost:6000/batch" },
    { name: "Cell Specification", path: "http://10:8080/data/fetch-data/cell" },
    { name: "Battery Specification", path: "http://localhost:8080/data/fetch-data/battery" },
    { name: "Component", path: "http://localhost:8080/data/fetch-data/component" },
    ];
  sourcePath: any;
  constructor(private assetService: AssetService, private dialogRef: MatDialogRef<AssetEditorDialog>,
    @Inject('STORAGE_TYPES') public storageTypes: StorageType[]) {
  }

  ngOnInit(): void {
  }

  onSave() {
    const assetEntryDto =
    {
      "@context": {},
      "asset": {
        "@type": "Asset",
        "@id": this.id,
        "properties": {
          "description": this.name
        }
      },
      "dataAddress": {
        "@type": "DataAddress",
        "type": "HttpData",
        "baseUrl": this.sourcePath
      }
    }

    this.dialogRef.close({ assetEntryDto });
  }
}
