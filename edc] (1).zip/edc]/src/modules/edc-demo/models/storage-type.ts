export interface StorageType {
    id: string;
    name: string;
}